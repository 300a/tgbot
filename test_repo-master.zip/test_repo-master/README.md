## HSE Lyceum IT Projects - test_repo

## Образец заявки на ИТ-проект и пользовательских сценариев
